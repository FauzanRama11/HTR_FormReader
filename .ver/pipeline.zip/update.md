# Update — Proposed Final Structure (A-F): Analysis & Phased Plan

**Date:** 8 September 2026
**Status:** RESOLVED. Phase 1's geometry fix (Section C) is DONE and
verified — see `handover.md` §4 for the full corrected story and real
numbers (`v15_1_dy_fix`: nomor_rekening 45%→58%, nominal_penempatan
24%→30%, nama_nasabah 26%→33%, zero regressions, 5/6 known block-shift
records visually confirmed fixed). The "Open problem" section below is kept
as-is for context on what was tried and rejected (2D distance, box-overlap)
before the working fix (Y-only comparison against title) was found — see
§"How it was actually resolved" appended at the end of this file. Remaining
Phase 1 work: Section A (output file restructure) and Section D (Stop
button always-visible) — not started yet, see `handover.md` §5 point 5.

## Where this picks back up

Read this section first, then §"Open problem" below, then resume from
§"Next steps" — everything else in this file is background/design record,
kept for context but not the active work item.

## What's actually done vs. claimed

- `preprocessing.py`: `estimate_section_transform` was rewritten (see
  `_fit_transform_from_anchors`, `_match_anchor_pool`,
  `TRANSLATION_DISAGREEMENT_DIST_RATIO`, `TITLE_ANCHOR_FALLBACK_MIN_SIMILARITY`)
  to always compute the title anchor and cross-check it against the
  field-only result's translation, overriding on disagreement. This is a
  real improvement over V15's original "only fall back when anchors look
  individually weak" logic (which missed confidently-wrong fits).
- **This fix is CONFIRMED CORRECT for exactly 2 of 6 known block-shift
  records (10, 22)** — both sections now agree and visually verified (record
  10 already checked in the prior session turn).
- **It is CONFIRMED STILL BROKEN or UNVERIFIED for records 13, 15, 19, 20.**
  Do NOT claim these are fixed. Do NOT run the full evaluation yet — the
  last two sessions both over-claimed after a partial check, and got caught
  by the user both times. Breaking that pattern is the point of this file.

## Open problem: distance-based cross-check is not a sufficient discriminator

Diagnosed by visually comparing the field-only box vs. the title-derived box
drawn directly on the aligned document (not by trusting either number):

| Record | Field-only translation | Title translation | 2D distance | Which is visually correct | Currently overridden? |
|---|---|---|---|---|---|
| 2 (`identity_area`) | (-25, 27) | (0, 1) | ~36px | **field-only** (verified: red box cleanly bounds all 3 real rows, green box is shifted up into the printed title) | No — correct |
| 13 (`identity_area`) | (-10, 24.5) | (2, 52) | ~30px | **title** (verified: green box bounds the 3 real rows — Nama Nasabah "Yadi Iskandar" / Nomor Rekening / Unit Kerja "BRI Unit Pasar Besar" — red box sits too high, overlapping "FORMULIR KEIKUTSERTAAN") | **No — WRONG, should be overridden** |

**The contradiction**: record 13 needs to be overridden with a *smaller*
disagreement distance (~30px) than record 2, which must NOT be overridden
(~36px). A single Euclidean-distance threshold on the translation vector
cannot separate these two cases — any threshold low enough to catch 13 also
wrongly catches 2, and any threshold that spares 2 also spares 13. This is
the actual reason the current `TRANSLATION_DISAGREEMENT_DIST_RATIO` (reusing
`SECTION_OUTLIER_DIST_RATIO`, ~51.6px on this template) can't be "tuned" to
fix this — it's not a tuning problem, the signal itself is insufficient.

Two more records are unresolved for a **different** reason (not yet visually
verified which candidate is correct for these — do that first before
theorizing further):
- Record 15: title anchor matched at similarity 0.448, record 19 at 0.496 —
  both BELOW `TITLE_ANCHOR_FALLBACK_MIN_SIMILARITY = 0.5`, so the title
  reference is discarded entirely before the distance comparison even runs.
  Both dy values (59, 54) look consistent with the real ~52-61px block-shift
  pattern seen in records 10/13/22, suggesting 0.5 is probably too strict a
  cutoff — but this hasn't been visually confirmed the way 2 and 13 were.
- Record 20: title anchor similarity only 0.310 (below even the base
  `SECTION_ANCHOR_MIN_SIMILARITY = 0.32`), so no title reference is available
  at all for this record. May need a different fix entirely, or may simply
  be a document this approach can't help — not yet investigated why the
  title match itself is weak here (blur? different letterhead layout?
  something else?).

## Ideas to evaluate next (not yet tried, not yet decided between)

1. **Use `field_result["method"]` as part of the decision, not just distance.**
   Record 2's safe case was `consensus_translation` (1 clean anchor). Record
   13's wrong case was presumably `section_affine` or `consensus_translation`
   from multiple mediocre anchors (check which — not yet confirmed). If wrong
   results specifically correlate with the affine path built from anchors
   that are ALL mediocre (like the originally-diagnosed placement_area case
   on record 10), a stricter distance tolerance specifically when
   `field_result["method"] == "section_affine"` AND all contributing anchors'
   similarities are below some "solid" bar (e.g. no anchor above ~0.5) might
   separate these cases better than raw distance alone.
2. **Reconsider what "distance" should even measure.** Comparing the full 2x2
   affine-transformed translation column conflates rotation/scale effects
   with pure vertical shift. Since the actual failure mode is specifically
   "letterhead height differs" (a Y-axis phenomenon), a Y-only comparison
   (or Y-weighted distance) might discriminate better than full 2D distance
   — untested, would need re-checking against records 2 AND 13 again since
   record 2's dy-diff (~26) and record 13's dy-diff (~27.5) are ALSO nearly
   identical, so a naive Y-only distance has the exact same contradiction.
   This suggests distance/geometry alone (in any single-number form) may be
   fundamentally insufficient, and the real discriminator might need to be
   evidence-based instead (see #3).
3. **Cross-check against actual content, not just geometry.** Instead of
   (or in addition to) comparing translations numerically, check what's
   inside the candidate box: does the field-only candidate's crop contain
   recognizable STATIC TEMPLATE TEXT (e.g. "FORMULIR KEIKUTSERTAAN", which is
   already known verbatim and is exactly what appears wrongly captured in
   record 13's red box)? This is conceptually the same "template-text
   leakage" detector already planned for Phase 2 (Section B of the original
   spec) — worth considering pulling that specific piece forward into this
   fix, since it may be the more fundamental/correct signal (evidence: is
   there template text in the box?) rather than a geometric proxy (how far
   is this translation from another translation?) that's been shown not to
   discriminate reliably.

Option 3 is the most promising lead — it directly explains both failing
cases (record 13's field-only box visibly contains "FORMULIR KEIKUTSERTAAN")
and doesn't depend on finding a magic distance threshold that may not exist.
It does mean pulling forward a piece of Phase 2 rather than keeping the
phases cleanly separated — worth it if it's what actually makes the
geometry decision correct, since a wrong geometry fix makes Phase 2's
field-level checks moot anyway (they'd be checking content extracted from
the wrong place).

## Next steps (resume here)

1. Visually check records 15, 19, 20 the same way records 2/13/10 were
   checked (draw both candidate boxes on the actual aligned document, look
   at which one bounds the real 3 rows) — don't theorize from numbers alone.
2. Decide between the ideas above (or a combination) based on what actually
   discriminates all 6 block-shift records + record 2 (and ideally 1-2 more
   known-clean records) correctly, verified visually per-record, not just
   by re-running the same 2-record spot check.
3. Only once ALL 6 block-shift records are visually confirmed fixed (both
   sections) AND record 2 (and other clean records) are confirmed
   unregressed, run the full 25-doc `evaluation.py` once.
4. Then proceed to Section A (output file restructure) and Section D (Stop
   button always-visible) — deliberately sequenced AFTER the geometry fix is
   solid, since both of those are lower-risk and shouldn't be measured
   against a moving/broken baseline.
5. Update `handover.md` with real, visually-verified numbers — the standing
   rule this session keeps re-learning: never claim "fixed" from a code read
   or a partial spot-check.

## Background: full section-by-section analysis of the original A-F spec

(Kept for reference — this is the design analysis from before implementation
started, still valid for Phase 2 planning once Phase 1's geometry fix is solid.)

**A. Visual structure.** Mostly straightforward, reuses data already computed:
- `{record}_original.jpg` = `prep.load_document()`'s output, unmodified. This
  function already applies zero correction (no rotation/contrast/alignment) —
  it's already exactly what's asked. No new code needed, just save it before
  any preprocessing touches it.
- `{record}_preprocessed.jpg` = `aligned_img` from `prepare_and_align()`,
  saved BEFORE `post.draw_debug` draws boxes on it. Need to confirm
  `draw_debug` doesn't mutate in place (if it does, copy first).
- `template_roi.jpg` as ONE shared file, cache-checked like the existing
  `template_preview.jpg` pattern (`app.py:197-203`).
- **Conflict**: the spec says "Do NOT create: `template_preview.jpg`" — but
  that file/endpoint (`app.py:197`, `GET /api/template-preview`) already
  exists for a DIFFERENT, unrelated feature (a plain blank-template preview
  shown elsewhere in the UI, `static/index.html:682`). Deleting it breaks
  that existing feature. **Assumption**: the spec means "don't create a NEW
  per-record template file," not "delete the existing unrelated
  template-preview endpoint" — proceed on that reading unless corrected.
- `{record}_roi_document.jpg` must reflect the FINAL post-retry ROI, not an
  intermediate snapshot. Trivial today (no retry loop exists yet), becomes
  load-bearing once Phase 2 exists.

**B. Quality gate + recovery pipeline.** `pipeline.py` already has a
multi-stage fallback chain (OCR Primary → Full-Page VLM → ROI/template
fallback → ROI second-pass VLM). Recommended: add new detectors
(template-text leakage, neighbor-label leakage, vertical clipping) as NEW
TRIGGER CONDITIONS feeding into that EXISTING chain, not a parallel retry
system. `comparison.py`'s `_name_similarity` is reusable for fuzzy matching.
Template-text corpus should be extracted from `assets/template.pdf` via
`pdfplumber` (same tool already used for coordinate extraction), not
hardcoded. torch/transformers are not installed in this dev environment, so
VLM-path testing is limited to trigger-logic verification here. **Note (new,
from this session's investigation): a piece of this — template-text leakage
detection — may need to move into Phase 1 if it turns out to be the correct
discriminator for the geometry cross-check (see "Open problem" above).**

**C. V15.1 cross-check.** See "Open problem" above — in progress, not done.

**D. Stop button.** `runRecords()` already funnels per-row/index-range/bulk
runs through the same `/api/sheet/submit` → single `_process_batch()` loop —
one shared cancellation mechanism already exists, doesn't need to be built.
Remaining work: change `display:none` default to always-visible/disabled,
and empirically verify (start a real run, observe) rather than trust a code
read. "Individual Run" is assumed to mean the Sheet tab's per-row button, not
Tab 1's separate synchronous upload flow. Not started yet this pass — comes
after the geometry fix per "Next steps" above.

**E. Notes/diagnostics.** `postprocessing.build_fields_table` already has a
`"notes"` field per row — new flags slot in directly. Phase 2 work.

**F. Validation order.** Sound, matches the project's established discipline.
Currently being followed more strictly than before (this file's existence is
that correction in action).

## How it was actually resolved

Neither idea #1 (method-aware threshold) nor #2 (Y-only distance, predicted
above to have the same contradiction) was used. A third approach worked:
compare field-only's own Y-translation against **two** references — 0 (no
correction / stuck at original template position) and the title's measured
Y-shift — rather than against a single distance threshold. Field-only is
overridden only when it's closer to "uncorrected" than to the title's real
shift (`|field_dy| < |field_dy - title_dy|`), and only when the title itself
shows a meaningful shift (`|title_dy| >= 15px`) — so documents with no real
block-shift never enter the comparison at all, regardless of field-only's own
value. This sidesteps the earlier contradiction (record 2 ~36px vs record 13
~30px) because it's not a single fixed distance threshold — it's relative to
each document's own measured shift. Also lowered
`TITLE_ANCHOR_FALLBACK_MIN_SIMILARITY` from 0.5 to 0.40, which rescued two
more legitimate title matches (records 15, 19) that the original threshold
had wrongly excluded. Verified: 5 of 6 known block-shift records fixed (3
visually confirmed by drawing boxes on the actual document), 3 known-clean
records confirmed byte-identical/unaffected, full 25-doc evaluation shows
real gains with zero regressions. One record (20) remains unresolved — the
title anchor itself fails to match there, a separate, uninvestigated cause.
See `handover.md` §4 and §6 for full detail and the "don't repeat" list.
