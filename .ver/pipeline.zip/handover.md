# HANDOVER — OCR Pipeline Preprocessing & Evaluation

**Last update:** 8 September 2026 (V15)
**Baca urutan:** 1 (deskripsi) → 2 (state) → 3 (next steps) → sisanya kalau perlu detail.
**Prinsip kerja:** MEASURE → FIND ROOT CAUSE → FIX → RE-EVALUATE. **Satu perubahan
kecil, satu pengukuran full 25-dokumen, baru lanjut** — V14 sengaja hanya 1 fix
(bukan sapuan banyak fix sekaligus) atas permintaan eksplisit user, supaya efek tiap
perubahan bisa diverifikasi dgn jelas & token/waktu sesi tidak boros.

## 1. Deskripsi Project

Membaca **Surat Pernyataan nasabah** (foto HP atau PDF hasil scan), mengekstrak field
(nama, no. rekening, nominal, tenor, reward, TTD), membandingkan dengan data referensi
spreadsheet, lalu menghasilkan `OK Lanjut Proses` / `Tolak` (+ alasan) / `Review`.

```
Document -> Preprocessing (align ke template) -> ROI per field -> OCR (PaddleOCR)
         -> [fallback VLM Qwen2-VL kalau OCR tidak yakin] -> Field Comparison -> Final Status
```

Dataset ground truth: `assets/ocr_evaluation.xlsx` (25 record) + `downloaded_documents/`
(25 dokumen ter-cache, JANGAN dihapus — re-download butuh akses Google Drive).

## 2. State Saat Ini (V13)

Root cause 3 bug (2 di produksi, 1 di evaluator) yang membuat evaluasi sebelumnya TIDAK
BISA DIPERCAYA (100% preprocessing gagal, 0% field accuracy terukur — bukan pipeline
buruk, tapi evaluatornya sendiri salah baca). Sudah diperbaiki + diverifikasi dgn
evaluation.py di 25 dokumen:

| Metrik                     | Sebelum (bug)     | Sesudah (fix)      |
|-----------------------------|-------------------|---------------------|
| alignment_success_rate      | 0.96 (1 gagal)    | **1.00** (0 gagal)  |
| pipeline_success_rate       | 0.96              | **1.00**            |
| field_accuracy (5 field)    | N/A semua (bug evaluator, BUKAN 0 sungguhan) | nama_nasabah 20%, nomor_rekening 33%, nominal_penempatan 24%, tenor_penempatan 83%, bentuk_reward 100% |
| decision_accuracy           | 0.08              | **0.12**            |
| avg processing time/doc     | 12.0s             | 10.8s               |

File referensi: `evaluation_summary_baseline_full.json` (sebelum) vs
`evaluation_summary_fixed_v13.json` (sesudah) — hasil mentah per-record ada di
`evaluation_results_*.csv`. JANGAN dihapus, ini bukti before/after.

### Perubahan yang dibuat

1. **`preprocessing.py` — `is_pdf_document()` (baru).** Dokumen hasil download Google
   Drive disimpan TANPA ekstensi (`data_input.download_drive_document`, file = `<file_id>`).
   Kode lama (`prepare_input`, `prepare_and_align`) cek `Path(path).suffix == ".pdf"` —
   SELALU False utk file tanpa ekstensi, jadi 7/25 dokumen yg sebenarnya PDF salah
   dikira foto & diproses lewat jalur rectify/enhance foto yg tidak relevan. Fix: sniff
   isi file (magic header `%PDF-`), reuse `_looks_like_pdf` yg sudah ada. Dipakai jg di
   `stage_evaluation.py` (`evaluate_preprocessing_gate`).

2. **`preprocessing.py` — `_find_document_quad()` (rewrite total, dipakai `rectify_photo`).**
   ROOT CAUSE UTAMA: deteksi kertas versi lama (Canny edge + `approxPolyDP` PERSIS 4
   titik) gagal menemukan boundary kertas pada **0 dari 25** foto — diverifikasi visual
   (lihat bukti di bawah). Tepi kertas di foto kamera nyata punya gradien SANGAT LEMBUT
   (fokus/bayangan/pencahayaan), jauh lebih lemah drpd kontras teks internal — Canny
   selalu menangkap teks dulu, tidak pernah menutup satu loop penuh sekeliling kertas.
   Fix: segmentasi KECERAHAN (Otsu threshold kertas-vs-latar, region-based, bukan
   gradien) sbg strategi utama, Canny adaptif sbg fallback terakhir. Terverifikasi:
   rasio area kertas terdeteksi naik dari ~0.02–0.06 (salah) jadi ~0.65–0.92 (sesuai
   visual). AMAN dipakai agresif krn `prepare_and_align()` cuma pakai hasil rectify
   kalau skor alignment-nya OBJEKTIF LEBIH BAIK drpd dokumen asli — quad yang meleset
   otomatis tidak dipakai.

3. **`evaluation.py` — `_extract_value()` key salah (bug evaluator, BUKAN pipeline).**
   `post.build_fields_table()` (production, `postprocessing.py`) menaruh nilai di key
   `"ocr_result"`. Evaluator lama menebak key `"normalized_value"/"value"/"text"/
   "label"/"final_value"` — TIDAK ADA yang cocok, jadi field_accuracy SELALU 0
   measurable utk SEMUA field/dokumen, terlepas dari akurasi pipeline sungguhan. Fix:
   tambah `"ocr_result"` sbg key prioritas pertama. Dipakai jg oleh `stage_evaluation.py`
   (reuse `ev9._extract_value`).

4. **`evaluation.py` + `stage_evaluation.py` — flag `--pipeline` / `--vlm-fallback`
   (baru).** Supaya bisa jalankan dataset yg SAMA lewat modul pipeline lain
   (`pipeline1.py` = versi V10/11 lama) atau toggle `VLM_FALLBACK_ENABLED` tanpa edit
   kode, lalu dibandingkan lewat `compare_runs.py` (baru) — gabungkan beberapa
   `evaluation_summary_<label>.json` / `stage_evaluation_summary_<label>.json` jadi satu
   tabel sisi-berdampingan (kolom pertama = baseline, kolom lain = delta).
   ```
   python evaluation.py --dataset assets/ocr_evaluation.xlsx --label paddle_only --vlm-fallback off
   python evaluation.py --dataset assets/ocr_evaluation.xlsx --label paddle_vlm  --vlm-fallback on
   python compare_runs.py evaluation_summary_paddle_only.json evaluation_summary_paddle_vlm.json
   ```

## 3. V14 — Fix ROI Bleeding Identity Area (SELESAI, terverifikasi)

**Masalah** (ditemukan dari inspeksi visual debug image `outputs/*_roi_document.jpg`
yg di-generate user via app.py setelah V13): box ROI `nama_nasabah`/`nomor_rekening`/
`unit_kerja_pengelola_rekening` sering overlap/tertukar antar baris. Root cause:
`FIELD_CONFIG` (`preprocessing.py:107-121`) mendefinisikan 3 baris identity_area
dgn **gap NOL** (baris N bawah == baris N+1 atas), dan `estimate_section_transform`
(`preprocessing.py:886-945`, fallback ~1038-1063) jatuh ke `consensus_translation`
(TIDAK bisa koreksi rotasi) kalau anchor section yg lolos outlier-rejection <3 —
baris yg jauh dari anchor drift ke wilayah baris tetangga yg tanpa margin. Safety net
`prep._clamp_field_box_y()` sudah ADA di codebase tapi sebelumnya cuma dipakai utk
`tempat_tanggal_surat`, TIDAK dipakai di jalur `dynamic_extraction.py`.

**Fix**: satu baris di `dynamic_extraction.py` `_resolve_field_boxes()` (~line 190) —
`target_px = prep._clamp_field_box_y(target_px, field_name, shape)` — **HANYA utk
`region_name == "identity_area"`**. Sempat dicoba universal (semua field/region)
tapi terbukti regresi di `placement_area` (lihat §4, dilarang diulang) krn box
`CHOICE_GROUPS` (opsi tenor/reward) overlap scr vertikal dgn baris teks di sana,
beda dari identity_area yg murni 3 baris teks tanpa choice box.

**Hasil terverifikasi** (`evaluation.py`, full 25 dokumen, 1 evaluator per run —
lihat §6 poin 7 soal RAM):

| Metrik | V13 (`fixed_v13`) | V14 (`roi_clamp_identity_only`) |
|---|---|---|
| pipeline_success_rate | 1.00 | 1.00 |
| alignment_success_rate | 1.00 | 1.00 |
| nama_nasabah accuracy | 0.20 (4/20) | **0.25 (4/16)** |
| nomor_rekening accuracy | 0.3333 (7/21) | **0.4444 (8/18)** |
| nominal_penempatan accuracy | 0.2381 (5/21) | 0.2381 (5/21) — **unchanged, sesuai rencana** (scoped away dari placement_area) |
| tenor_penempatan accuracy | 0.8333 (5/6) | 0.80 (4/5) — noise n-kecil, bukan regresi (versi universal yg regresi ke 0.75 sudah dibuang) |
| bentuk_reward accuracy | 1.00 (10/10) | 1.00 (10/10) |
| decision_accuracy | 0.12 | **0.16** |

File bukti: `evaluation_summary_fixed_v13.json` (before) vs
`evaluation_summary_roi_clamp_identity_only.json` (after, FINAL — dipakai). File
`evaluation_summary_roi_clamp_fix.json` (versi universal yg DIBUANG) disimpan sbg
bukti kenapa scoping ke identity_area diperlukan — JANGAN dipakai sbg baseline.

**Keterbatasan yang masih tersisa (diverifikasi via debug image, BUKAN tebakan):**
Fix ini menghilangkan OVERLAP antar box (record 5: sekarang 3 baris terpisah bersih,
lihat sebelumnya 1 baris tanpa box sama sekali). TAPI untuk dokumen dgn drift lebih
besar (record 1: seluruh blok 3-baris bergeser ~1 baris penuh ke bawah relatif thd
window template), box yg sudah bersih/non-overlap TETAP bisa "kosong" (window benar
scr geometri, tapi kontennya sendiri sudah bukan di situ lagi) — `nomor_rekening`
record 1 jadi `None` (aman, masuk review, BUKAN salah-tapi-percaya-diri spt
sebelumnya), sementara `unit_kerja_pengelola_rekening` malah membaca isi
`nomor_rekening` (field ini TIDAK termasuk 5 field yg dibandingkan evaluation.py,
jadi tidak terlihat di metrik, tapi tercatat di sini utk next step). Ini BUKAN bug
dari fix V14 — ini kasus drift SATU ARAH SELURUH BLOK yg tidak bisa diperbaiki cuma
dgn clamp batas tetangga (clamp mencegah overlap, tidak memperbaiki posisi absolut).
Perbaikan sesungguhnya perlu localisasi PER-BARIS independen (bukan 1 transform
section utk semua baris) — opsi ini sudah dipertimbangkan sblm V14 tapi ditolak sbg
scope-lebih-besar; sekarang ada bukti konkret (record 1) knp itu next step yg valid.

## 4. V15 — Title Anchor + ROI Height Growth + Stop Button + Debug Cleanup (SELESAI)

Dipicu oleh permintaan user setelah audit visual 25-dokumen fresh
(`outputs/aa93e09523da_*_roi_document.jpg`, batch YANG SAMA dipakai utk hitung
kategori di bawah): 11/25 (44%) bersih, **6/25 (24%) "block-shift"** (records
10/13/15/19/20/22 — letterhead cabang lebih TINGGI drpd template, identity_area
DAN placement_area jatuh di teks judul/paragraf, field asli TANPA box sama
sekali), 5/25 (20%) residual row-drift (sisa dari V14, lihat §3), 1/25 (4%)
rotasi tak terkoreksi (record 6). User minta 4 hal sekaligus (bukan 1 spt V14 —
lihat instruksi eksplisit di §11):

**4a. Title anchor (root cause block-shift).** Judul cetak "FORMULIR
KEIKUTSERTAAN"/"Program BRI CUAN HADIAH 2026" (bbox normalized diukur langsung
dari `template.pdf`: `(0.38, 0.111, 0.63, 0.136)`) SELALU ada & posisinya
konsisten thd identity_area/placement_area — dipakai sbg anchor tambahan
dgn toleransi pencarian jauh lebih lebar (`TITLE_ANCHOR_SEARCH_TOL_X/Y`,
`preprocessing.py`), krn toleransi anchor field biasa (`ANCHOR_SEARCH_TOL_Y`
±31px) TERBUKTI tidak menjangkau selisih tinggi letterhead nyata (~60-100px).

**PENTING — jangan diulang:** percobaan PERTAMA menggabungkan anchor judul ke
POOL yang sama dgn anchor field (median lalu similarity-weighted average) —
DIBUANG. Anchor judul & anchor field bisa SAMA-SAMA valid tapi mengukur offset
lokal berbeda di posisi halaman berbeda; merata-ratakan 2 kebenaran berbeda
menghasilkan kesalahan ketiga.

**Desain V15 AWAL (INCOMPLETE — diganti V15.1, lihat di bawah, JANGAN
kembalikan):** `estimate_section_transform()` dipecah jadi
`_fit_transform_from_anchors()` + `_match_anchor_pool()`, dipanggil 2x
terpisah, anchor judul dipakai sbg fallback translasi-sendirian HANYA kalau
similarity TERTINGGI anchor field < `FIELD_ANCHORS_WEAK_MAX_SIMILARITY`
(0.36). **User menemukan (via live-app screenshot, BUKAN dari klaim kode)
bahwa fix ini SETENGAH JADI**: `identity_area` benar diperbaiki tapi
`placement_area` TIDAK, krn placement_area punya 4 anchor bersimilarity
biasa-biasa saja (0.33-0.45, semua > 0.36) yg lolos ke `estimateAffinePartial2D`
& menghasilkan fit yg LULUS semua sanity check (rotasi 4.5°, scale 0.96)
TAPI SALAH scr faktual (dy=-13, padahal judul menunjukkan dy=+61 di dokumen
yg SAMA). Trigger "similarity anchor individual rendah" TIDAK CUKUP jadi
sinyal "apakah HASIL fit-nya benar" — fit yg salah bisa tetap lulus semua
pengecekan yg ada.

**V15.1 (desain final, TERVERIFIKASI):** anchor judul SELALU dicocokkan
(bukan cuma saat field terlihat lemah) dan dipakai sbg CROSS-CHECK thd
translasi-Y hasil field-only. Dua pendekatan cross-check DICOBA & DIBUANG
sebelum ketemu yg benar — **jangan diulang**:
1. *Jarak translasi 2D penuh* (`field_result.M[:,2]` vs `title_result.M[:,2]`,
   ambang `SECTION_OUTLIER_DIST_RATIO*diagonal`) — DIBUANG. Record 2
   (`identity_area`, HARUS dipertahankan) berjarak ~36px dari judul; record 13
   (`identity_area`, HARUS di-override) berjarak ~30px — LEBIH KECIL drpd
   record 2. Satu ambang jarak scr matematis tidak bisa memisahkan 2 kasus ini.
2. *Overlap kotak kandidat vs kotak judul* (geometris, cek tumpang tindih
   area) — DIBUANG. Benar utk `identity_area` (record 13 overlap ~95% vs
   record 4/bersih overlap ~36% hanya krn kedekatan template nominal — bukan
   leakage sungguhan), TAPI gagal total utk `placement_area` (record 10):
   box placement_area yg salah nangkring di PARAGRAF LAIN, bukan judul itu
   sendiri, jadi tidak pernah tumpang tindih dgn kotak judul sama sekali.

**Fix yang benar-benar bekerja**: bandingkan translasi-Y SAJA (fenomena
block-shift murni pergeseran vertikal) thd DUA rujukan — 0 (posisi template
asli) dan translasi-Y judul (pergeseran sungguhan, independen section mana
pun). Field-only dianggap "nyangkut di posisi asli" (anchornya gagal
menjangkau konten yg sudah bergeser) kalau `|field_dy| < |field_dy -
title_dy|` — sinyal ini berlaku SAMA baik yg nyangkut itu ada di judul
(identity_area) MAUPUN di paragraf lain (placement_area), krn tidak
bergantung pd APA yg ada di lokasi salah itu. Judul HANYA dipakai sbg rujukan
kalau `|title_dy| >= MIN_TITLE_SHIFT_PX` (15px) — dokumen normal (judul
sendiri dy~0-1px) TIDAK PERNAH masuk perbandingan ini sama sekali, jadi tidak
pernah override hasil field-only yg sudah genuinely benar, terlepas translasi
field-only-nya sendiri berapa. `TITLE_ANCHOR_FALLBACK_MIN_SIMILARITY`
diturunkan dari 0.5 ke **0.40** (0.5 terlalu ketat, membuang 2 match judul yg
genuine: record 15 sim=0.448, record 19 sim=0.496 — keduanya konsisten dgn
pola pergeseran nyata ~52-78px).

**Hasil per-record (dari 6 record block-shift yg diketahui), diverifikasi
VISUAL (box digambar di dokumen asli, bukan cuma baca angka M):**
- Record 10, 13, 15: **identity_area DAN placement_area keduanya benar**,
  dikonfirmasi visual langsung (record 15: nama/rekening/unit kerja DAN
  nominal/tenor/reward semua correctly boxed, cocok GT).
- Record 22: kedua section konsisten via title fallback (belum di-screenshot
  ulang, tapi angka M konsisten dgn pola yg sudah diverifikasi visual di 3
  record lain).
- Record 19: `identity_area` diperbaiki (title fallback); `placement_area`
  TIDAK di-override tapi itu BENAR — fit `section_affine`-nya sendiri
  (dy=50.6) sudah dekat dgn nilai judul (dy=54), tidak perlu override.
- Record 20: **MASIH TIDAK TERSELESAIKAN** — anchor judul sendiri cuma
  similarity 0.310 (di bawah bahkan `SECTION_ANCHOR_MIN_SIMILARITY`=0.32),
  genuinely tidak ketemu dgn cukup yakin di dokumen ini. Root cause berbeda
  (kenapa judul sendiri gagal match di sini — blur? layout beda? belum
  diinvestigasi), BUKAN sesuatu yg diperbaiki fix ini. Known limitation.
- Record 2, 4, 12 (bersih): TIDAK berubah sama sekali (diverifikasi angka M
  identik sebelum/sesudah) — fix ini tidak menyentuh dokumen yg sudah benar.

**4b. ROI height growth (overflow baris ke-2).** Ditemukan terpisah dari
inspeksi zoom record 2: teks terbilang nilai reward yang panjang overflow ke
baris ke-2 SAMA SEKALI tidak ter-assign ke field manapun (window fixed-height,
tidak ada mekanisme growth spt `extract_handwriting_crop` yg sudah ada utk
`tempat_tanggal_surat`). Fix: `_grow_window_downward()` (`dynamic_extraction.py`)
— perluas SISI BAWAH window asosiasi (bukan target_px/posisi asli, bukan sisi
atas) sejauh `prep.ROI_EXTRA_HEIGHT_RATIO` (1x tinggi field), di-cap KERAS ke
`prep.NEXT_FIELD_TOP_NORM` (batas field tetangga, sudah ada, dihitung utk
SEMUA field) supaya tidak pernah menembus baris berikutnya. **PENTING — jangan
diulang:** sempat diterapkan ke SEMUA 7 field, TERBUKTI regresi
`nominal_penempatan` (field angka 1-baris, tidak overflow, growth-nya cuma
nambah risiko tanpa manfaat). Di-scope ULANG ke `GROWABLE_FIELDS = {"reward_tunai"}`
saja (`dynamic_extraction.py`) — SATU-SATUNYA field yg terkonfirmasi overflow.
`reward_tunai` sendiri TIDAK termasuk 5 field yang dibandingkan `evaluation.py`
(lihat `FIELD_GT_MAP`), jadi perbaikan ini tidak terlihat di metrik agregat
tapi tetap benar utk `raw_json`/export Excel.

**4c. Stop button** (`app.py` + `static/index.html`): endpoint baru
`POST /api/sheet/cancel/{session_id}` set flag `cancel_requested` di session
dict; `_process_batch()` cek flag itu di ATAS tiap iterasi SEBELUM mulai
record berikutnya (record yg SEDANG jalan tetap selesai wajar, TIDAK
diinterupsi) lalu tandai sisa record `queued` jadi `cancelled`. Tombol
`sheetStopBtn` (di sebelah `sheetBulkRunBtn`, TIDAK menggantikannya) tampil
hanya selagi `batch-status` melaporkan `active`, nonaktif lagi setelah
`cancel_requested` true atau proses benar2 berhenti.

**4d. Debug output cleanup**: `app.py` berhenti menyimpan
`{request_id}_roi_template.jpg` per record (25 file nyaris-duplikat/batch,
cuma beda warna kotak overlay — base template-nya statis). Field
`roi_template_url` dihapus dari response; panel "Template (ROI)" di UI
(`roiTemplateBox`/`sheetRoiTemplateBox`, kedua tab) juga dihapus krn sumber
gambarnya sudah tidak ada. `_roi_document.jpg` (foto asli + kotak, sinyal
diagnostik sebenarnya) & `template_preview.jpg` (cache singleton, sudah ada
sejak sebelumnya) TIDAK berubah.

**Hasil terverifikasi FINAL (V15.1 dy-relative fix, `evaluation.py`, full 25
dokumen) — ini angka yang BENAR, abaikan angka V15-awal di commit/draft
sebelumnya kalau ketemu, sudah digantikan:**

| Metrik | V14 (`roi_clamp_identity_only`) | V15 awal (`v15_final`, INCOMPLETE) | **V15.1 (`v15_1_dy_fix`, FINAL)** |
|---|---|---|---|
| pipeline_success_rate | 1.00 | 1.00 | 1.00 |
| alignment_success_rate | 1.00 | 1.00 | 1.00 |
| nama_nasabah accuracy | 0.25 (4/16) | 0.2632 (5/19) | **0.3333 (6/18)** |
| nomor_rekening accuracy | 0.4444 (8/18) | 0.45 (9/20) | **0.5789 (11/19)** |
| nominal_penempatan accuracy | 0.2381 (5/21) | 0.2381 (5/21) | **0.3043 (7/23)** |
| tenor_penempatan accuracy | 0.80 (4/5) | 0.80 (4/5) | 0.80 (4/5) — unchanged |
| bentuk_reward accuracy | 1.00 (10/10) | 1.00 (9/9) | 1.00 (9/9) — unchanged |
| decision_accuracy | 0.16 | 0.16 | 0.16 — unchanged (lihat §6 poin 6) |
| review_rate | 0.0 | 0.0 | **0.12** — dokumen ambigu sekarang jujur masuk REVIEW, bukan dipaksa OK/TOLAK |

File bukti: `evaluation_summary_v15_1_dy_fix.json` (FINAL, dipakai). File V15
awal (`v15_title_anchor`/`v15_final`) disimpan sbg bukti historis "kenapa
fix pertama tidak cukup" — JANGAN dipakai sbg baseline, lihat tabel di atas
utk perbandingan yg benar.

**Catatan jujur**: kenaikan kali ini NYATA & lebih besar (nomor_rekening naik
13 poin, nominal_penempatan naik 6.6 poin, measurable count ikut naik utk
ketiganya — artinya lebih banyak dokumen yg field-nya sekarang genuinely
ter-ekstrak, bukan cuma akurasi di antara yg sudah measurable). `review_rate`
naik dari 0 ke 0.12 adalah sinyal SEHAT (bukan regresi) — sebelumnya semua
dokumen dipaksa OK/TOLAK tegas walau datanya ambigu; sekarang beberapa
record correctly masuk status "perlu direview" krn ROI sekarang benar-benar
merefleksikan ketidakpastian yg genuine. `decision_accuracy` belum bergerak
krn 7-check-nya sendiri masih ketat — lihat §6 poin 6, bukan soal ROI lagi.

## 5. V15.2 — Output Structure + Field Quality Gate (Leakage) + Stop Always-Visible

Lanjutan permintaan user (lihat `update.md` utk analisis lengkap section A-F
asli) — dikerjakan Section A, C (sudah termasuk di §4), D, dan SEBAGIAN B.
Section E (notes-only, tidak ada gambar baru) otomatis terpenuhi krn desain
di bawah. **Section B (quality gate) HANYA SEBAGIAN — baca catatan jujur di
akhir sebelum menganggap ini "selesai".**

**Section A — struktur output (`pipeline.py`, `app.py`).** `debug_images`
sekarang jg mengembalikan `original` (dokumen mentah, SEBELUM preprocessing
apa pun — `filled_raw`, sudah dihitung `run_pipeline` tapi sebelumnya tidak
diekspos) dan `preprocessed` (`aligned_img`, SEBELUM kotak ROI digambar).
`app.py` menyimpan `{request_id}_original.jpg` / `_preprocessed.jpg` /
`_roi_document.jpg` per record + SATU `template_roi.jpg` bersama (fungsi baru
`_ensure_template_roi_image()`, cache-checked spt `template_preview.jpg` yg
sudah ada SEBELUMNYA & TETAP dipertahankan — beda fungsi, jangan hapus).
`_preview.jpg` lama (di-load+simpan terpisah SEBELUM `_run_ocr_and_format`
dipanggil, duplikat kerja) dihapus, di-alias ke `original_url` yg baru.
Diverifikasi lewat HTTP nyata (server test di port 8002, endpoint
`/api/sheet/*`) — bukan cuma baca kode: `outputs/` sesudah 1 record berisi
PERSIS `template_roi.jpg` (1x, dipakai bersama), `{id}_original.jpg`,
`{id}_preprocessed.jpg`, `{id}_roi_document.jpg`, `{id}_preview.jpg` (Tab 1
lama) — TIDAK ADA lagi `_roi_template.jpg` atau file debug lain.

**Section D — Stop button** (`static/index.html`): `display:none` diganti
`disabled` (tombol SELALU tampil, cuma status enabled/disabled berubah).
Enable SEGERA saat submit (bukan tunggu poll pertama), disable lagi lewat
poll `batch-status` (`!stillRunning || cancel_requested`). CSS `.btn-stop`/
`.btn-stop:disabled` baru (inline style lama akan KETIMPA `button:disabled`
global krn inline style menang atas class selector manapun kecuali
`!important` — ini kenapa harus pindah ke class, bukan cuma soal rapi).
"Individual/Index/Bulk Run" SUDAH lewat SATU jalur (`runRecords()` →
`/api/sheet/submit` → `_process_batch()`, dikonfirmasi lewat grep) — tidak
ada 3 mekanisme terpisah yg perlu disatukan, itu ASUMSI SALAH di permintaan
awal, arsitekturnya sudah begitu sejak V15.

**Diverifikasi EMPIRIK lewat HTTP nyata (bukan baca kode)**: upload dataset →
submit record 1-6 → cancel saat record 1 masih `processing` → tunggu record 1
selesai → hasil PERSIS sesuai spec: record 1 `done` (TIDAK diinterupsi),
record 2-6 `cancelled` (TIDAK pernah mulai), record 7+ tetap `pending`,
`active` jadi `False`, `cancel_requested` ke-reset `False` (siap run baru
tanpa refresh), hasil record 1 tetap bisa di-fetch (`/api/sheet/result/...`
mengembalikan fields + `template_roi_url`/`original_url`/`preprocessed_url`
lengkap).

**Section B — field quality gate (SEBAGIAN, HANYA leakage detection).**
`preprocessing.extract_template_static_text()` (baru): ekstrak fragmen teks
cetak dari `template.pdf` via **pymupdf** (SUDAH dependency — bukan
pdfplumber, komentar lama yg menyebut pdfplumber cuma soal proses ekstraksi
KOORDINAT manual satu-kali dulu, BUKAN dependency runtime; pdfplumber TIDAK
terpasang di venv ini, jangan install kalau tidak perlu). Di-cache in-memory
(1x per proses). `pipeline._detect_template_leakage(value)` (baru): cek tiap
field yg statusnya SUDAH "read" (OCR Primary percaya diri) apakah value-nya
ternyata cocok fuzzy dgn salah satu fragmen itu (label sendiri/tetangga/
judul/paragraf) — reuse `dynamic._fuzzy_contains` yg SUDAH ada (bukan bikin
fuzzy-match baru). Diwire ke `_text_fallback_reason()` (titik keputusan
eskalasi yg SUDAH ada, dipakai oleh SEMUA 3 tahap fallback existing) sbg
alasan baru `"template_leakage"` — bukan retry-engine terpisah, PERSIS sesuai
rekomendasi `update.md` (pakai infrastruktur fallback yg sudah ada).

Diverifikasi 2 lapis:
1. Unit-level: string kontaminasi yg SUDAH terkonfirmasi sesi ini
   ("Program BRI CUAN HADIAH 2026", "FORMULIR KEIKUTSERTAAN") terdeteksi
   BENAR; nama/nomor rekening/cabang asli TIDAK false-positive.
2. Full dataset (25 dokumen NYATA, bukan string sintetis): gate AKTIF
   BENERAN, nemu 4 field kontaminasi asli — record 5
   (`unit_kerja_pengelola_rekening` = `"3701-01-03219055 engelola Rekening"`,
   fragmen "Unit Kerja Pengelola Rekening"), record 7 (`nama_nasabah` =
   `"Program BRI CUAN HADIAH 2026 ah Ratem"`), record 10
   (`unit_kerja_pengelola_rekening` = `"Pengelola Rekening"`), record 24
   (`nama_nasabah` = `"Program BRI CUAN HADIAH 2026 Syanril Alamyah"`).

**Catatan JUJUR (baca sebelum lanjut ke Section B lainnya)**: full evaluation
(`v15_2_leakage_gate` vs `v15_1_dy_fix`) menunjukkan **angka akurasi PERSIS
IDENTIK, nol perubahan** — walau gate di atas TERBUKTI aktif & benar
mendeteksi 4 kontaminasi nyata. Kenapa: gate SUDAH benar mengeskalasi ke
fallback chain yg ADA (`_run_vlm_fullpage_fallback` → gagal senyap krn
torch/transformers tidak terpasang di environment ini, lihat exception
handling yg SUDAH ada, aman/tidak crash — lalu lanjut ke
`_run_roi_template_fallback`), TAPI fallback ROI/template yg ADA cuma
meng-OCR ULANG crop yg SAMA (`row["roi_bbox"]` yg sudah dikoreksi V15.1),
BUKAN mencoba posisi ROI yang BERBEDA. Utk kasus "partial merge" (konten asli
GENUINE bercampur dgn fragmen judul/label yg bocor, spt record 7/24 di atas)
OCR ulang di crop yg sama akan membaca campuran yg SAMA lagi. **Recovery
sesungguhnya (positional re-localization/local row snapping, "geometric
retry" di spec asli) BELUM dibangun** — itu kenapa akurasi tidak bergerak
meski deteksi sudah benar. Ini BUKAN bug, ini scope yg memang belum
dikerjakan — jangan diklaim "Section B selesai" sampai ini ada.

**Section B yang BELUM dikerjakan sama sekali (jangan asumsikan sudah ada)**:
- ROI clipping detection (B.C) — belum ada kode sama sekali.
- Positional re-localization / local row snapping sbg AKSI recovery baru
  (bukan cuma re-OCR crop yg sama) — belum ada.
- Group-aware sibling re-check (kalau 1 field mencurigakan, cek field
  seangkatan di region yg sama) — belum ada.
- Bounded retry count (`max 1 retry per field`) + notes vocabulary lengkap
  (`geometric_retry`/`shared_area_correction`/`retry_success`/`retry_failed`)
  — belum ada, baru `template_leakage` sbg satu-satunya notes key baru.

## 6. Prioritas Berikutnya (berdasar data V15.2 di atas, BUKAN tebakan)

1. **Section B recovery yg SESUNGGUHNYA (positional re-localization)** —
   prioritas TERTINGGI skrg krn deteksi (leakage gate, §5) SUDAH terbukti
   benar tapi TIDAK BERGUNA tanpa aksi recovery yg bisa mengubah POSISI ROI,
   bukan cuma re-OCR crop yg sama. Kandidat konkret: kalau
   `_detect_template_leakage` return match pd fragmen JUDUL (dy besar
   kemungkinan), coba title-anchor-relative correction serupa V15.1 utk
   field itu SENDIRI; kalau match pd fragmen LABEL TETANGGA, coba geser ke
   arah field tetangga yg labelnya ketemu (row snapping). Test on record
   7/24 (`nama_nasabah`) dan record 5/10 (`unit_kerja_pengelola_rekening`) —
   4 kasus nyata SUDAH terdeteksi & terekam sesi ini, tinggal perlu recovery
   yg PAS utk memvalidasi.
2. **ROI clipping detection (Section B.C)** — belum ada kode sama sekali.
   Perlu akses ke ink-coverage/crop boundary (bukan cuma `row["value"]` teks
   spt leakage detection) — kemungkinan perlu parameter tambahan ke
   `_text_fallback_reason` atau titik integrasi berbeda drpd leakage gate.
3. **Record 20 masih tidak terselesaikan** — anchor judul sendiri gagal
   match dgn cukup yakin (sim=0.310) di dokumen ini, beda root cause dari 5
   record block-shift lain yg sudah fix. Investigasi KENAPA judul gagal match
   di sini spesifik (blur? layout letterhead beda lagi? window pencarian
   `TITLE_ANCHOR_SEARCH_TOL_Y` masih kurang lebar utk kasus ini?) sebelum
   coba fix apa pun — jangan asumsikan sama dgn 5 record lain.
4. **ROI sudah benar (5/6 block-shift record) tapi OCR masih salah baca**
   tulisan tangan yg buram/miring pd dokumen2 itu — jalankan
   `stage_evaluation.py --label v15_2 --dataset assets/ocr_evaluation.xlsx`
   (belum sempat di-run sesi ini) utk pisahkan ROI-fail vs OCR-fail per field
   scr formal, atau evaluasi apakah VLM fallback (`pipeline.VLM_FALLBACK_ENABLED`,
   perlu `torch`+`transformers`, lihat `requirements.txt`) membantu — domain
   yg PAS utk VLM (deskriptif dari konteks visual), BEDA dari masalah ROI yg
   sudah selesai (deterministik, geometris).
5. **Per-baris localisasi independen utk identity_area** (bukan 1 shared
   section transform) — utk kasus drift-satu-blok spt record 1 (lihat §3,
   BEDA dari block-shift V15.1 — record 1 bukan soal letterhead, tapi rotasi
   residual kecil). Pendekatan: cari ink band lokal di sekitar window tiap
   baris (mirip `_find_ink_bands` yg sudah ada). Belum dikerjakan.
6. **decision_accuracy stuck di 0.16** walau field accuracy naik nyata —
   cek `decision_reasons` di `evaluation_results_v15_1_dy_fix.csv` utk lihat
   check mana yg paling sering gagal (7-check jauh lebih ketat drpd akurasi
   per-field individual — field yg sekarang benar blm tentu cukup utk lolos
   SEMUA 7 check sekaligus).
7. Mesin evaluasi ini hanya ~8GB RAM — **JANGAN** jalankan 2 evaluator penuh
   (25 dokumen) bersamaan (sudah beberapa kali trigger OOM/MemoryError sesi
   lalu). Jalankan satu-satu, atau pakai `--limit` utk uji cepat dulu.

## 7. Sudah Dicoba / Jangan Diulang (hemat waktu+token sesi berikutnya)

- Canny edge (`Canny(50,150)` tetap atau adaptif) utk deteksi boundary kertas → SUDAH
  dikonfirmasi gagal total di dataset ini (visual + rasio area), JANGAN kembalikan jadi
  strategi utama. Otsu brightness segmentation (§2, poin 2) adalah fix yg terbukti bekerja.
- Cek suffix file (`Path(path).suffix == ".pdf"`) utk deteksi PDF pada dokumen hasil
  download → SELALU salah utk file tanpa ekstensi. Selalu pakai `prep.is_pdf_document()`.
- Key `"value"/"normalized_value"/"text"/"label"/"final_value"` sbg SUMBER UTAMA baca
  hasil field di evaluator → key asli production adalah `"ocr_result"` (tetap ada sbg
  fallback di `_extract_value`, tapi jangan andalkan itu duluan).
- **Menerapkan `_clamp_field_box_y` scr UNIVERSAL ke semua region** (bukan hanya
  identity_area) → SUDAH dicoba (`evaluation_summary_roi_clamp_fix.json`), TERBUKTI
  regresi di `placement_area` (`rentang_tenor` record 15/18: MATCH→N/A) krn
  `CHOICE_GROUPS` box (opsi tenor/reward) overlap vertikal dgn baris teks di sana.
  JANGAN diulang tanpa dulu memperbaiki bagaimana `PREV_FIELD_BOTTOM_NORM`/
  `NEXT_FIELD_TOP_NORM` menghitung tetangga saat ada choice-box yg overlap.
- **(V15) Menggabung anchor judul ke pool anchor field yg sama** (median atau
  rata-rata berbobot similarity) → DIBUANG, lihat §4a. Anchor judul & anchor
  field bisa sama-sama valid tapi mengukur offset lokal BERBEDA di posisi
  halaman berbeda — jangan dirata-rata, pakai sbg fallback translasi terpisah
  (`title_anchor` param di `estimate_section_transform`, tidak pernah campur).
- **(V15) `_grow_window_downward` diterapkan ke SEMUA field** (bukan hanya yg
  terkonfirmasi overflow) → TERBUKTI regresi `nominal_penempatan`, lihat §4b.
  Field angka 1-baris tidak butuh growth; JANGAN tambah field baru ke
  `GROWABLE_FIELDS` (`dynamic_extraction.py`) tanpa bukti overflow spesifik
  spt reward_tunai (zoom debug image, bukan tebakan).
- **(V15) Trigger title-fallback berdasar "similarity anchor field individual
  rendah"** (`FIELD_ANCHORS_WEAK_MAX_SIMILARITY`) → TERBUKTI tidak cukup:
  placement_area bisa lolos jadi `section_affine` yg confidently WRONG walau
  semua anchor individualnya "biasa saja" (bukan rendah). Diganti V15.1 (lihat
  §4a) — jangan kembalikan trigger berbasis similarity-individual.
- **(V15.1, percobaan 1) Cross-check pakai jarak translasi 2D penuh**
  (`np.linalg.norm` antara `field_result.M[:,2]` dan `title_result.M[:,2]`) →
  DIBUANG. Record 2 (harus dipertahankan) jarak ~36px vs record 13 (harus
  di-override) jarak ~30px — kontradiksi matematis, satu ambang tidak bisa
  memisahkan keduanya. Jangan coba lagi dgn ambang berbeda, masalahnya bukan
  di angka ambang, tapi di bentuk perbandingannya (2D penuh, bukan Y saja).
- **(V15.1, percobaan 2) Cross-check pakai overlap kotak kandidat vs kotak
  judul** (area tumpang tindih geometris) → DIBUANG. Benar utk identity_area
  TAPI placement_area yg salah nangkring di PARAGRAF LAIN (bukan judul), jadi
  tidak pernah terdeteksi lewat overlap dgn judul. Diganti perbandingan
  translasi-Y polos (lihat §4a) yg tidak bergantung pd APA yg ada di lokasi
  yg salah.
- **(V15.2) `pdfplumber` DIKIRA dependency runtime** krn komentar lama di
  `preprocessing.py` menyebutnya — SALAH, `pdfplumber` TIDAK terpasang di
  venv ini & TIDAK ada di `requirements.txt`. Komentar itu soal proses
  ekstraksi KOORDINAT manual satu-kali dulu (di luar aplikasi), bukan
  dependency yg jalan tiap request. Pakai **pymupdf** (`fitz`, SUDAH
  dependency) utk ekstrak teks — `preprocessing.extract_template_static_text()`.
  Jangan install pdfplumber kalau tidak benar-benar perlu fitur yg pymupdf
  tidak punya.
- **(V15.2) Menganggap "deteksi leakage terpasang" = "Section B selesai"**
  → SALAH, lihat §5 catatan jujur. Deteksi tanpa aksi recovery yg bisa ubah
  POSISI ROI (bukan cuma re-OCR crop yg sama) TIDAK mengubah akurasi apa pun
  — 4 kontaminasi nyata terdeteksi BENAR sesi ini, nol yg ke-fix, krn
  fallback ROI/template yg ADA cuma re-OCR di crop yg SAMA. Jangan laporkan
  gate ini sbg "fix" tanpa recovery yg benar2 mengubah posisi.

## 8. Cara Re-run Evaluasi (perintah persis)

```bash
# end-to-end (field accuracy + decision accuracy) -- paling relevan utk "akurasi asli"
python evaluation.py --dataset assets/ocr_evaluation.xlsx --label <nama_run> --debug-dir none

# 3-gate funnel (PREPROCESSING -> ROI -> OCR), CER, dst -- utk isolasi root cause per stage
python stage_evaluation.py --dataset assets/ocr_evaluation.xlsx --label <nama_run> --no-xlsx --debug-dir none

# uji cepat sebelum full run (hemat waktu ~12s/dokumen)
python evaluation.py --dataset assets/ocr_evaluation.xlsx --label smoke --limit 5 --debug-dir none

# bandingkan beberapa run (lihat §2, poin 4)
python compare_runs.py evaluation_summary_<a>.json evaluation_summary_<b>.json
```

## 9. Peta File

**Aktif (produksi, di-import `app.py`/`pipeline.py`):** `preprocessing.py`, `ocr.py`,
`postprocessing.py`, `dynamic_extraction.py`, `comparison.py`, `vlm.py`, `pipeline.py`,
`data_input.py`, `app.py`, `static/index.html`.

**Evaluasi (standalone CLI, tidak di-import app.py):** `evaluation.py`,
`stage_evaluation.py`, `compare_runs.py` (V13).

**Eksperimen/versi lama, TIDAK di-import mana pun secara aktif (verifikasi ke user
sebelum dihapus — mungkin masih dipakai manual utk banding V10/11 vs V12 lewat
`--pipeline pipeline1`):** `pipeline1.py`/`pipeline2.py`, `comparison1.py`/`comparison2.py`,
`postprocessing1.py`, `vlm1.py`, `index1.html`, `static/index1.html`,
`static/serep2.html`/`serep3.html`/`serep4.html`/`serep6.html`.

## 10. Field & Rules (tidak berubah dari versi sebelumnya)

Field: Nama (fuzzy match 80%), Nomor Rekening, Unit Kerja, Nominal Penempatan, Tenor
(dari rentang tanggal, <1 bulan = tidak sesuai), Bentuk Reward (tunai/non-tunai +
fallback), TTD Nasabah & TTD Unit Kerja/BRI (presence only, bukan baca isi).

Rule rural (`Urban` != "urban" di data): cukup validasi Nama, Nomor Rekening, Nominal
Penempatan, TTD Nasabah, TTD BRI — kalau semua lolos, `OK Lanjut Proses`.

Environment: Windows, FastAPI `127.0.0.1:8001`, GPU NVIDIA MX230 2GB (PaddleOCR
mayoritas jalan CPU di environment evaluasi), `MAX_CANVAS_HEIGHT_GPU=2200` /
`_CPU=6000`, `text_recognition_batch_size=1` (low VRAM GPU kecil).

## 11. Instruksi utk Claude (sesi berikutnya)

1. Baca §1-6 dulu — itu cukup utk lanjut kerja tanpa re-explore dari nol.
2. Jangan ulangi §7 (sudah dicoba & terbukti gagal/terbukti benar).
3. Sebelum ubah kode: jalankan evaluator (§8), baca angkanya, baru putuskan.
4. **Default: satu perubahan kecil per sesi, langsung diverifikasi full
   25-dokumen** (bukan sapuan banyak fix sekaligus). V15 adalah PENGECUALIAN
   krn user eksplisit minta 4 hal sekaligus dlm satu pesan — kalau itu terjadi
   lagi, tetap verifikasi tiap perubahan YANG BERISIKO REGRESI (mis. logika
   ROI/transform) satu-satu sebelum lanjut ke perubahan berikutnya, spt yg
   dilakukan utk 4a/4b di atas (masing2 ketahuan overreach-nya justru krn
   dites terpisah, bukan digabung langsung).
5. Setelah ubah kode: update §2/§3/§4/§5 (state tiap versi) di file ini dgn
   angka baru — bukan cuma cerita naratif, supaya sesi berikutnya bisa
   langsung baca tabel.
6. Jangan jalankan 2 evaluator penuh (25 dokumen) bersamaan (§6 poin 7,
   resource mesin cuma ~8GB RAM, sudah beberapa kali OOM/MemoryError).
