"""
extractors.py
==============
V19 -- Multi-extractor benchmark router. Adds 4 alternative extractors
(Gemini 3.8 Flash, Gemini 2.5 Flash, Mistral OCR 4.1, Qwen2-VL-2B-Instruct)
alongside the existing, UNCHANGED V18 pipeline (`pipeline.run_pipeline`), so
`app.py`/`evaluation.py` can benchmark all five under the SAME
comparison/decision logic (`comparison.py`, not touched by this module).

Design (see handover.md for the full writeup):
  - `run(engine, document_path, ...)` is the ONLY entry point other modules
    should call -- a single if/elif/else dispatch (see bottom of this file).
    Exactly ONE engine executes per call, NEVER a fan-out, NEVER an automatic
    fallback from one engine to another (Qwen's own bounded fallback to v18,
    `run_qwen_vlm`, is the one documented exception -- task spec section 6 --
    and stays entirely inside that single dispatch branch).
  - `run_v18` is a thin passthrough to `pipeline.run_pipeline()` -- V18's own
    internals (preprocessing/template alignment/ROI/PaddleOCR/VLM fallback)
    are NOT touched by this session's work.
  - `run_gemini`/`run_mistral` read ONLY the original document bytes (no
    `preprocessing.load_document`/template alignment/ROI/PaddleOCR involved --
    the whole point is to measure NATIVE AI extraction) and NEVER receive
    `reference_record` (structurally impossible for them to leak ground
    truth into the prompt -- their signatures don't even accept it).
  - `run_qwen_vlm` does MINIMAL image preparation only (PDF->image, EXIF
    orientation, safe resize -- NO deskew/threshold/binarize/ROI crop/label
    detection/PaddleOCR) and asks the local Qwen2-VL-2B-Instruct model to
    read the WHOLE document semantically in one call (`vlm.
    extract_direct_semantic`). Falls back to the existing v18 OCR/ROI
    pipeline ONLY when Qwen itself fails to produce a valid structured
    result -- never preemptively, never to Gemini/Mistral.
  - All four non-v18 engines parse their response into the CANONICAL schema
    (`COMMON_FIELDS`, task spec) via `adapt_common_to_pipeline_shape()`, which
    builds the EXACT SAME top-level return shape `pipeline.run_pipeline()`
    produces (`fields`/`raw_results`/`choice_groups`/`debug_images`/etc) by
    REUSING `postprocessing.build_fields_table()` -- so `app.py`/
    `evaluation.py` need almost no changes downstream of `run()`.
  - Gemini calls additionally capture real token usage (`gemini_usage`, top
    level of the result dict) from the API response's `usage_metadata` and
    compute cost from `config.py`'s pricing (never hardcoded here) -- see
    `_compute_gemini_cost`.
"""

import base64
import json
import os
import time
from pathlib import Path

import cv2

import config
import pipeline
import postprocessing as post
import preprocessing as prep
import vlm

# ============================================================================
# CANONICAL SCHEMA (task spec) + SHARED EXTRACTION INSTRUCTION
# ============================================================================

COMMON_FIELDS = (
    "nama_nasabah", "nomor_rekening", "unit_kerja_pengelola_rekening",
    "nominal_penempatan", "tenor_penempatan", "tanggal_mulai", "tanggal_selesai",
    "bentuk_reward", "signature_nasabah", "signature_atasan",
)

# Verbatim from the task spec -- kept as ONE shared constant, used by BOTH
# Gemini and Mistral prompts, so the two engines are given the identical
# instruction (only the structured-output mechanism differs per SDK).
EXTRACTION_INSTRUCTION = """You are a document data extraction engine.

Read the attached Indonesian banking declaration/participation document visually.

Extract only information actually visible in the document.

Extract:
- customer name
- account number
- managing unit
- placement amount
- placement tenor
- start date
- end date
- reward type
- customer signature presence
- bank/unit representative signature presence

Use document labels, handwriting, typed text, checkboxes, marks, dates, currency values and visual context.

Do not infer missing values.
Do not use external/reference data.
Do not include printed labels or headers as field values.
Do not guess unreadable characters.
If ambiguous, return uncertain.
If absent, return not_detected.

Signature detection means presence only, not biometric signature verification.

Return only the required structured schema."""


def _response_json_schema():
    """JSON schema for native structured output (Gemini response_schema /
    Mistral document_annotation_format) -- each extracted field is wrapped as
    {"value": ..., "status": "detected"|"uncertain"|"not_detected"} so the AI
    can express uncertainty WITHOUT corrupting the value's type (task's flat
    canonical example is the CONCEPTUAL contract; this wrapper is the wire
    format that keeps typing strict for structured-output validation).
    Signatures are a bare enum since their "value" already IS the status."""
    status_enum = ["detected", "uncertain", "not_detected"]

    def wrapped(value_schema):
        return {
            "type": "object",
            "properties": {"value": value_schema, "status": {"type": "string", "enum": status_enum}},
            "required": ["value", "status"],
        }

    return {
        "type": "object",
        "properties": {
            "nama_nasabah": wrapped({"type": ["string", "null"]}),
            "nomor_rekening": wrapped({"type": ["string", "null"]}),
            "unit_kerja_pengelola_rekening": wrapped({"type": ["string", "null"]}),
            "nominal_penempatan": wrapped({"type": ["integer", "null"]}),
            "tenor_penempatan": wrapped({"type": ["integer", "null"]}),
            "tanggal_mulai": wrapped({"type": ["string", "null"], "description": "ISO date YYYY-MM-DD"}),
            "tanggal_selesai": wrapped({"type": ["string", "null"], "description": "ISO date YYYY-MM-DD"}),
            "bentuk_reward": wrapped({"type": ["string", "null"], "enum": ["tunai", "non_tunai", None]}),
            "signature_nasabah": {"type": "string", "enum": ["present", "absent", "uncertain"]},
            "signature_atasan": {"type": "string", "enum": ["present", "absent", "uncertain"]},
        },
        "required": list(COMMON_FIELDS),
    }


# ============================================================================
# ERRORS (task §14) -- one exception type, `stage` maps directly onto the 4
# new evaluation.py FAILURE_STAGES entries. Never silently swallowed, never
# triggers a fallback to another engine (callers just let it propagate).
# ============================================================================


class ExtractorError(Exception):
    """stage: one of API_AUTH / API_RATE_LIMIT / API_TIMEOUT / API_RESPONSE."""

    def __init__(self, message, stage="API_RESPONSE"):
        super().__init__(message)
        self.stage = stage


class InvalidExtractor(ExtractorError):
    def __init__(self, engine):
        super().__init__(f"Unknown extractor engine: {engine!r}", stage="API_RESPONSE")


def _classify_api_exception(exc):
    """Best-effort classification of an SDK exception into one of the 4
    stages, from its type name + message -- same string-matching style
    already used by app.py's sanitize_error()/_ERROR_HINTS, not a new
    pattern introduced here."""
    text = f"{type(exc).__name__} {exc}".lower()
    if any(k in text for k in ("unauthorized", "invalid api key", "authentication", "permission_denied", "401", "403", "api key not valid")):
        return "API_AUTH"
    if any(k in text for k in ("rate limit", "quota", "resource_exhausted", "429", "too many requests")):
        return "API_RATE_LIMIT"
    if any(k in text for k in ("timeout", "timed out", "connection", "network", "unavailable", "deadline", "dns")):
        return "API_TIMEOUT"
    return "API_RESPONSE"


# ============================================================================
# SHARED HELPERS
# ============================================================================


def _progress(callback, step, percent, message):
    """Mirrors pipeline._emit_progress()'s exact behavior (clamp 0-100, never
    let a callback exception break the extractor) so app.py's existing
    progress-polling plumbing works unchanged for every engine."""
    if callback is None:
        return
    try:
        callback({"step": step, "percent": int(max(0, min(100, percent))), "message": message})
    except Exception:
        pass


def _read_file_for_upload(document_path):
    """Raw bytes + best-effort MIME type -- NO cv2/pymupdf rasterization, NO
    template alignment. Reuses prep.is_pdf_document()'s existing magic-header
    sniff (needed because data_input.get_document_path() returns downloaded
    files WITHOUT an extension) for the PDF/image split; falls back to a
    simple PNG-signature check, defaulting to JPEG (the common case for
    phone-camera uploads in this dataset)."""
    with open(document_path, "rb") as f:
        raw_bytes = f.read()
    if prep.is_pdf_document(document_path):
        return raw_bytes, "application/pdf"
    if raw_bytes[:8] == b"\x89PNG\r\n\x1a\n":
        return raw_bytes, "image/png"
    return raw_bytes, "image/jpeg"


_ID_MONTHS = {
    1: "Januari", 2: "Februari", 3: "Maret", 4: "April", 5: "Mei", 6: "Juni",
    7: "Juli", 8: "Agustus", 9: "September", 10: "Oktober", 11: "November", 12: "Desember",
}


def _format_id_date(iso_str):
    """'2026-01-01' -> '1 Januari 2026' -- confirmed parseable by the
    EXISTING, REUSED postprocessing._extract_dates() (Indonesian month-name
    regex), so derive_tenor_from_range() works unmodified on AI-extracted
    dates exactly as it does on OCR'd handwritten text."""
    if not iso_str:
        return None
    try:
        y, m, d = (int(p) for p in str(iso_str).split("-")[:3])
        return f"{d} {_ID_MONTHS[m]} {y}"
    except Exception:
        return None


def _field_entry(common, name):
    """Read one wrapped {"value":..., "status":..., "confidence":...} field
    from the parsed AI response; defensive flat-value fallback in case a
    response ever comes back unwrapped. Returns (value, status, confidence).
    "confidence" is None for Gemini/Mistral (their wire schema,_response_
    json_schema(), has no confidence key -- .get() harmlessly returns None,
    preserving the V18-session behavior of put()'s confidence=None exactly);
    only Qwen's canonical dict (see _adapt_qwen_to_common) populates it."""
    raw = common.get(name) if isinstance(common, dict) else None
    if isinstance(raw, dict):
        value = raw.get("value")
        status = raw.get("status") or ("not_detected" if value in (None, "") else "detected")
        return value, status, raw.get("confidence")
    return raw, ("not_detected" if raw in (None, "") else "detected"), None


# ============================================================================
# ADAPTER -- canonical AI JSON -> EXACT pipeline.run_pipeline() return shape
# ============================================================================


def adapt_common_to_pipeline_shape(common, source, document_path):
    """`common`: parsed JSON matching `_response_json_schema()`. `source`:
    engine/model name, stamped onto every field's "source" + `ocr_meta`.
    NEVER receives/reads a reference_record -- structurally cannot leak
    ground truth (see module docstring).

    V19 adapter design decision (documented in full in handover.md): V18's
    comparison.validate_tenor()/validate_reward() are built around the PAPER
    FORM's "two independent pieces of evidence must agree" design (a
    checkbox mark + a hand-written date range for tenor; a checkbox mark + a
    filled detail field for reward) -- this doesn't map 1:1 onto a single AI
    JSON response.
      - Tenor: genuinely honest reuse. The canonical schema already gives TWO
        independently-extracted signals from the SAME AI response --
        tenor_penempatan (a number) and tanggal_mulai/tanggal_selesai (dates).
        Both are fed in as-is; if the AI's own number and its own date range
        disagree, validate_tenor correctly flags TOLAK -- catching genuine AI
        self-inconsistency, a real feature of reusing this check.
      - Reward: a real simplification, not a fabrication. Only ONE
        bentuk_reward value exists in the canonical schema (no separate
        "detail" field), so the SAME value is mirrored into whichever of
        reward_tunai/reward_non_tunai it matches, purely so the existing
        "detail field filled" check has a witness instead of reporting a
        false REVIEW on every API-engine record. This is a known, deliberate
        simplification with no independent second signal available for
        whole-document AI extraction -- flagged here and in handover.md."""
    final_results = {}

    def put(name, value, status, reason=None, confidence=None):
        final_results[name] = {
            "value": value,
            "raw": (str(value) if value is not None else None),
            "status": status, "confidence": confidence, "source": source, "reason": reason,
        }

    nama, nama_status, nama_conf = _field_entry(common, "nama_nasabah")
    put("nama_nasabah", nama, nama_status, confidence=nama_conf)

    rekening, rekening_status, rekening_conf = _field_entry(common, "nomor_rekening")
    put("nomor_rekening", str(rekening) if rekening is not None else None, rekening_status, confidence=rekening_conf)

    unit, unit_status, unit_conf = _field_entry(common, "unit_kerja_pengelola_rekening")
    put("unit_kerja_pengelola_rekening", unit, unit_status, confidence=unit_conf)

    nominal, nominal_status, nominal_conf = _field_entry(common, "nominal_penempatan")
    put("nominal_penempatan", nominal, nominal_status, confidence=nominal_conf)

    tenor, tenor_status, tenor_conf = _field_entry(common, "tenor_penempatan")
    tanggal_mulai, _tm_status, _tm_conf = _field_entry(common, "tanggal_mulai")
    tanggal_selesai, _ts_status, _ts_conf = _field_entry(common, "tanggal_selesai")

    range_raw = None
    d1, d2 = _format_id_date(tanggal_mulai), _format_id_date(tanggal_selesai)
    if d1 and d2:
        range_raw = f"{d1} s/d {d2}"
    final_results["rentang_tenor"] = {
        "value": range_raw, "raw": range_raw,
        "status": "detected" if range_raw else "not_detected",
        "confidence": None, "source": source, "reason": "derived_from_tanggal_mulai_selesai",
    }
    tenor_choice_status = "detected" if tenor is not None else "review"
    final_results["tenor_penempatan"] = {
        "value": tenor, "status": tenor_choice_status, "source": source, "reason": "ai_extracted",
        "confidence": tenor_conf,
    }

    reward, _reward_status, reward_conf = _field_entry(common, "bentuk_reward")
    reward = reward if reward in ("tunai", "non_tunai") else None
    put("reward_tunai", (reward if reward == "tunai" else None),
        "detected" if reward == "tunai" else "not_detected")
    put("reward_non_tunai", (reward if reward == "non_tunai" else None),
        "detected" if reward == "non_tunai" else "not_detected")
    reward_choice_status = "detected" if reward is not None else "review"
    final_results["bentuk_reward"] = {
        "value": reward, "status": reward_choice_status, "source": source, "reason": "ai_extracted",
        "confidence": reward_conf,
    }

    _SIG_LABEL = {"present": "Ada tanda tangan", "uncertain": "Perlu verifikasi manual", "absent": "Kosong"}
    for name in ("signature_nasabah", "signature_atasan"):
        raw_sig = common.get(name) if isinstance(common, dict) else None
        state = raw_sig if raw_sig in ("present", "absent", "uncertain") else "uncertain"
        final_results[name] = {
            "value": _SIG_LABEL[state], "status": state, "present": state == "present",
            "reason": "ai_extracted", "source": source,
        }

    fields_table = post.build_fields_table(final_results, post.FIELD_TYPES)

    choice_groups = {
        "tenor_penempatan": {"value": tenor, "status": tenor_choice_status, "reason": "ai_extracted"},
        "bentuk_reward": {"value": reward, "status": reward_choice_status, "reason": "ai_extracted"},
    }

    # No alignment/ROI concept for API engines -- reuse the SAME raw loaded
    # document for all 3 debug-image slots so app.py's EXISTING debug-image
    # saving code (unchanged by this session) keeps working as-is.
    raw_img = prep.load_document(str(document_path))
    debug_images = {"template": raw_img, "document": raw_img, "original": raw_img, "preprocessed": raw_img}

    return {
        "alignment": {"status": "not_applicable", "method": "api_extraction", "engine": source},
        "input_preparation": {"rectified": False, "reason": "not_applicable_api_engine"},
        "fields": fields_table,
        "groups": {},
        "choice_groups": choice_groups,
        "raw_results": final_results,
        "field_errors": {},
        "debug_images": debug_images,
        "dynamic_regions_debug": {},
        "ocr_meta": {"strategy": f"api_extraction_{source}", "engine": source, "ocr_calls": 1},
    }


# ============================================================================
# ENGINE: V18 (thin passthrough, V18 internals untouched)
# ============================================================================


def run_v18(document_path, progress_callback=None, reference_record=None):
    """reference_record IS forwarded here (unlike run_gemini/run_mistral)
    because pipeline.run_pipeline() already uses it internally in an
    existing, previously-audited way (_run_vlm_reference_check, predates
    this session) -- unrelated to the Gemini/Mistral no-reference-leakage
    guarantee, which is about NOT giving ground truth to an external API."""
    result = pipeline.run_pipeline(
        str(document_path), progress_callback=progress_callback, reference_record=reference_record
    )
    result.setdefault("ocr_meta", {})["engine"] = "v18"
    return result


# ============================================================================
# ENGINE: Gemini (3.8 Flash / 2.5 Flash -- same function, different model id)
# ============================================================================


def _compute_gemini_cost(model, input_tokens, output_tokens, thinking_tokens):
    """V19 sec 8 -- reads config.py (GEMINI_PRICING/GEMINI_DEFAULT_PRICING/
    USD_IDR_RATE), NEVER hardcodes a price here -- update config.py when
    Gemini's pricing changes, this function stays untouched."""
    pricing = config.GEMINI_PRICING.get(model, config.GEMINI_DEFAULT_PRICING)
    input_cost = input_tokens / 1_000_000 * pricing["input_per_1m"]
    output_cost = (output_tokens + thinking_tokens) / 1_000_000 * pricing["output_per_1m"]
    cost_usd = input_cost + output_cost
    return cost_usd, cost_usd * config.USD_IDR_RATE


def run_gemini(document_path, model, progress_callback=None):
    _progress(progress_callback, "prepare", 10, "Preparing document")
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ExtractorError("GEMINI_API_KEY environment variable is not set", stage="API_AUTH")

    try:
        from google import genai
        from google.genai import types
    except ImportError as exc:
        raise ExtractorError(
            f"google-genai package not installed ({exc}); see requirements.txt", stage="API_AUTH"
        ) from exc

    raw_bytes, mime_type = _read_file_for_upload(document_path)

    _progress(progress_callback, "extract", 35, f"Extracting with {ENGINE_LABELS.get(model, model)}")
    client = genai.Client(api_key=api_key)
    # `response_schema` is validated as `google.genai.types.Schema`, an
    # OpenAPI-style Pydantic model whose `type` field is a SINGLE strict enum
    # (STRING/NUMBER/INTEGER/.../NULL) -- it cannot represent a standard JSON
    # Schema nullable union (`"type": ["string", "null"]`, what
    # `_response_json_schema()` emits for every Optional field), which is
    # exactly what crashed here before. `response_json_schema` (confirmed
    # present on the installed google-genai's `GenerateContentConfig`, wired
    # straight through to the request via `t_json_schema()`, a no-op
    # passthrough -- NOT validated as `types.Schema`) accepts plain JSON
    # Schema natively, so the ORIGINAL dict is used as-is here -- no dialect
    # conversion, no stripped nullability.
    schema = _response_json_schema()

    # NOTE: exact SDK call shape (client.models.generate_content, Part.from_bytes)
    # matches the google-genai SDK's documented structured-output usage at the
    # time this was written -- verify against the currently-installed package
    # version if this raises an unexpected TypeError/AttributeError, since SDK
    # method signatures can change between releases.
    response = None
    last_exc = None
    for attempt in range(2):
        try:
            response = client.models.generate_content(
                model=model,
                contents=[
                    types.Part.from_bytes(data=raw_bytes, mime_type=mime_type),
                    EXTRACTION_INSTRUCTION,
                ],
                config={"response_mime_type": "application/json", "response_json_schema": schema},
            )
            break
        except Exception as exc:
            last_exc = exc
            stage = _classify_api_exception(exc)
            if stage != "API_TIMEOUT" or attempt == 1:
                raise ExtractorError(str(exc), stage=stage) from exc
            time.sleep(1.5)  # bounded retry, ONLY for transient transport errors
    if response is None:
        raise ExtractorError(str(last_exc), stage="API_TIMEOUT")

    _progress(progress_callback, "validate", 70, "Validating extraction")
    try:
        common = json.loads(response.text)
    except Exception as exc:
        raise ExtractorError(f"invalid structured response from Gemini: {exc}", stage="API_RESPONSE") from exc

    result = adapt_common_to_pipeline_shape(common, source=model, document_path=document_path)

    # V19 sec 7-8 -- actual usage from the API response's usage_metadata
    # (NEVER estimated when this is available, per task spec), cost from
    # config.py (see _compute_gemini_cost). Stored at TOP LEVEL of the
    # result (not nested in ocr_meta) so app.py/export can read it directly
    # -- absent entirely for every other engine, so "don't show Gemini cost
    # for non-Gemini records" falls out naturally (nothing to show).
    usage = getattr(response, "usage_metadata", None)
    input_tokens = getattr(usage, "prompt_token_count", 0) or 0
    output_tokens = getattr(usage, "candidates_token_count", 0) or 0
    thinking_tokens = getattr(usage, "thoughts_token_count", 0) or 0
    total_tokens = getattr(usage, "total_token_count", 0) or (input_tokens + output_tokens + thinking_tokens)
    cost_usd, cost_idr = _compute_gemini_cost(model, input_tokens, output_tokens, thinking_tokens)
    result["gemini_usage"] = {
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "thinking_tokens": thinking_tokens,
        "total_tokens": total_tokens,
        "estimated_cost_usd": round(cost_usd, 6),
        "estimated_cost_idr": round(cost_idr, 2),
    }

    _progress(progress_callback, "done", 100, "Complete")
    return result


# ============================================================================
# ENGINE: Mistral OCR
# ============================================================================


def run_mistral(document_path, model, progress_callback=None):
    _progress(progress_callback, "prepare", 10, "Preparing document")
    api_key = os.getenv("MISTRAL_API_KEY")
    if not api_key:
        raise ExtractorError("MISTRAL_API_KEY environment variable is not set", stage="API_AUTH")

    try:
        # v2.x of the SDK made top-level `mistralai` a pure namespace package
        # (no __init__.py, `mistralai.azure`/`mistralai.gcp` are sibling
        # cloud-specific variants) -- the `Mistral` client class now lives
        # under `mistralai.client`, not re-exported at the top level anymore
        # (the old `from mistralai import Mistral`, valid in 1.x, silently
        # resolves to the empty namespace package instead of raising a clear
        # "wrong version" error -- confirmed against the installed 2.10.0).
        from mistralai.client import Mistral
    except ImportError as exc:
        raise ExtractorError(
            f"mistralai package not installed ({exc}); see requirements.txt", stage="API_AUTH"
        ) from exc

    raw_bytes, mime_type = _read_file_for_upload(document_path)
    encoded = base64.b64encode(raw_bytes).decode("ascii")
    document_payload = (
        {"type": "document_url", "document_url": f"data:{mime_type};base64,{encoded}"}
        if mime_type == "application/pdf" else
        {"type": "image_url", "image_url": f"data:{mime_type};base64,{encoded}"}
    )

    _progress(progress_callback, "extract", 35, f"Extracting with {ENGINE_LABELS.get(model, model)}")
    client = Mistral(api_key=api_key)
    schema = _response_json_schema()

    # NOTE: exact SDK call shape (client.ocr.process, document_annotation_format,
    # response.document_annotation) matches Mistral's documented OCR +
    # document-annotation structured-extraction usage at the time this was
    # written -- verify against the currently-installed mistralai package
    # version's docs if this raises an unexpected error, since "mistral-ocr-
    # 4-1" is a caller-supplied model id not independently verifiable here.
    response = None
    last_exc = None
    for attempt in range(2):
        try:
            response = client.ocr.process(
                model=model,
                document=document_payload,
                document_annotation_format={
                    "type": "json_schema",
                    "json_schema": {"name": "surat_pernyataan_extraction", "schema": schema, "strict": True},
                },
            )
            break
        except Exception as exc:
            last_exc = exc
            stage = _classify_api_exception(exc)
            if stage != "API_TIMEOUT" or attempt == 1:
                raise ExtractorError(str(exc), stage=stage) from exc
            time.sleep(1.5)
    if response is None:
        raise ExtractorError(str(last_exc), stage="API_TIMEOUT")

    _progress(progress_callback, "validate", 70, "Validating extraction")
    try:
        annotation = getattr(response, "document_annotation", None)
        common = json.loads(annotation) if isinstance(annotation, str) else annotation
        if not isinstance(common, dict):
            raise ValueError("document_annotation missing or not an object")
    except Exception as exc:
        raise ExtractorError(f"invalid structured response from Mistral: {exc}", stage="API_RESPONSE") from exc

    result = adapt_common_to_pipeline_shape(common, source=model, document_path=document_path)
    _progress(progress_callback, "done", 100, "Complete")
    return result


# ============================================================================
# ENGINE: Qwen2-VL (V19 -- PRIMARY EXPERIMENTAL pipeline, direct semantic
# extraction. NO PaddleOCR, NO fixed ROI/label coordinates, NO field crop
# before inference -- task spec section 1. Falls back to the EXISTING v18
# OCR/ROI pipeline ONLY when Qwen itself fails to produce a valid structured
# result (task spec section 6); never runs OCR/ROI preemptively/before Qwen,
# never fans out to Gemini/Mistral.
# ============================================================================

# Maps pipeline.py's per-field "source" values (see pipeline.py's own
# `candidate["source"] = ...` assignments) to the coarse fallback-source
# label recorded for Qwen mode (task spec section 6 examples). Reused as-is,
# not reinvented -- pipeline.py already distinguishes these internally.
QWEN_FALLBACK_SOURCE_LABELS = {
    "roi_template": "ROI Fallback",
    "roi_second_pass_vlm": "ROI Fallback",
    "vlm_fullpage": "OCR Fallback",
    "ocr_primary": "OCR Fallback",
}

QWEN_UNCERTAIN_CONFIDENCE = 0.5  # Qwen's OWN self-reported confidence below
                                  # this -> status "uncertain" (an EXISTING
                                  # comparison.py status, see
                                  # UNCERTAIN_FIELD_STATUSES) -- not a new
                                  # validation rule, just how low self-
                                  # reported confidence is surfaced.


def _qwen_prepare_image(document_path):
    """Minimal preparation ONLY (task spec section 1): PDF -> rendered image
    (reuses prep.load_document's existing PyMuPDF render -- NO template
    alignment), EXIF orientation correction for photos (PIL.ImageOps.
    exif_transpose -- cv2.imread applies EXIF too on most builds, but this is
    explicit per the task spec's requirement), safe resize (handled
    downstream by vlm.extract_direct_semantic's existing MAX_SIDE_FULL cap
    at inference time, see vlm.py). Deliberately NOT doing: deskew,
    threshold, binarize, ROI crop, label detection first, PaddleOCR first --
    the model inspects the WHOLE, un-cropped document."""
    if prep.is_pdf_document(document_path):
        return prep.load_document(str(document_path))
    import numpy as np
    from PIL import Image, ImageOps
    pil_img = ImageOps.exif_transpose(Image.open(str(document_path))).convert("RGB")
    return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)


def _adapt_qwen_to_common(qwen_result):
    """Map the V19 Qwen direct-semantic contract (task spec section 2:
    nama/nomor_rekening/nominal_penempatan/tenor_penempatan/bentuk_reward/
    signature_nasabah/signature_bri, each {value, confidence}) onto the
    COMMON_FIELDS canonical schema shared with Gemini/Mistral, so
    adapt_common_to_pipeline_shape() is reused UNCHANGED.

    Honest, disclosed limitation (NOT silently hidden, matching the Reward
    simplification already documented on adapt_common_to_pipeline_shape
    above): Qwen's REQUIRED schema (task spec section 2, fixed -- this
    function must not invent extra fields to work around it) has no
    unit_kerja/tanggal_mulai/tanggal_selesai, so those come back as
    not_detected/null here. comparison.validate_tenor() (UNCHANGED) demands
    the tenor choice number AND a derived date range as 2 independent pieces
    of evidence -- with no date range from Qwen, tenor_penempatan will
    consistently land on REVIEW via validate_tenor's existing "date range
    not read" branch. This is a real, disclosed consequence of Qwen's fixed
    minimal schema (same category as the Reward simplification above), not a
    bug to paper over by fabricating a date range Qwen was never asked for."""
    def wrap(value, confidence):
        confidence = confidence or 0.0
        if value in (None, ""):
            status = "not_detected"
        elif confidence < QWEN_UNCERTAIN_CONFIDENCE:
            status = "uncertain"
        else:
            status = "detected"
        return {"value": value, "status": status, "confidence": confidence}

    nama = qwen_result.get("nama") or {}
    rekening = qwen_result.get("nomor_rekening") or {}
    nominal = qwen_result.get("nominal_penempatan") or {}
    tenor = qwen_result.get("tenor_penempatan") or {}
    reward = qwen_result.get("bentuk_reward") or {}
    sig_nasabah = qwen_result.get("signature_nasabah") or {}
    sig_bri = qwen_result.get("signature_bri") or {}

    tenor_value = tenor.get("value")
    try:
        tenor_value = int(tenor_value) if tenor_value is not None else None
    except (TypeError, ValueError):
        tenor_value = None

    reward_value = reward.get("value")
    reward_value = reward_value if reward_value in ("tunai", "non_tunai") else None

    rekening_value = rekening.get("value")
    rekening_value = str(rekening_value) if rekening_value not in (None, "") else None

    return {
        "nama_nasabah": wrap(nama.get("value"), nama.get("confidence")),
        "nomor_rekening": wrap(rekening_value, rekening.get("confidence")),
        "unit_kerja_pengelola_rekening": {"value": None, "status": "not_detected", "confidence": 0.0},
        "nominal_penempatan": wrap(nominal.get("value"), nominal.get("confidence")),
        "tenor_penempatan": wrap(tenor_value, tenor.get("confidence")),
        "tanggal_mulai": {"value": None, "status": "not_detected", "confidence": 0.0},
        "tanggal_selesai": {"value": None, "status": "not_detected", "confidence": 0.0},
        "bentuk_reward": wrap(reward_value, reward.get("confidence")),
        "signature_nasabah": "present" if sig_nasabah.get("value") else "absent",
        "signature_atasan": "present" if sig_bri.get("value") else "absent",
    }


def run_qwen_vlm(document_path, progress_callback=None, reference_record=None):
    """V19 PRIMARY experimental engine. `reference_record` is NEVER given to
    Qwen's own prompt (same no-leakage guarantee as run_gemini/run_mistral --
    vlm.extract_direct_semantic's signature doesn't even accept it); it is
    only forwarded to the v18 FALLBACK call below, same precedent as
    run_v18 itself accepting it (see that function's docstring)."""
    _progress(progress_callback, "prepare", 10, "Preparing document (minimal, no ROI)")
    try:
        image_bgr = _qwen_prepare_image(document_path)
        _progress(progress_callback, "extract", 35, f"Extracting with {ENGINE_LABELS.get('qwen2_vl')}")
        qwen_result, _raw_text = vlm.extract_direct_semantic(image_bgr)
    except Exception as exc:
        # Task spec section 6: Qwen -> invalid structured result -> fall back
        # to the EXISTING OCR/ROI pipeline (v18), NOT to Gemini/Mistral, and
        # NOT run preemptively before Qwen was attempted.
        _progress(progress_callback, "fallback", 40,
                   f"Qwen2-VL unavailable/invalid ({exc}); falling back to existing OCR/ROI pipeline")
        result = run_v18(document_path, progress_callback=progress_callback, reference_record=reference_record)
        raw_sources = {row.get("source") for row in (result.get("raw_results") or {}).values() if isinstance(row, dict)}
        fallback_label = next(
            (QWEN_FALLBACK_SOURCE_LABELS[s] for s in raw_sources if s in QWEN_FALLBACK_SOURCE_LABELS),
            "OCR Fallback",
        )
        meta = result.setdefault("ocr_meta", {})
        meta["fallback_source"] = fallback_label
        meta["primary_engine_attempted"] = "qwen2_vl"
        meta["primary_engine_error"] = str(exc)
        return result

    _progress(progress_callback, "validate", 70, "Validating extraction")
    common = _adapt_qwen_to_common(qwen_result)
    result = adapt_common_to_pipeline_shape(common, source="qwen2_vl", document_path=document_path)
    result["ocr_meta"]["strategy"] = "qwen_direct_semantic"
    result["ocr_meta"]["fallback_source"] = "Qwen VLM"
    result["ocr_meta"]["qwen_confidence"] = {
        f: (qwen_result.get(f) or {}).get("confidence") for f in vlm.DIRECT_SEMANTIC_FIELDS
    }
    _progress(progress_callback, "done", 100, "Complete")
    return result


# ============================================================================
# ROUTER -- the ONLY function app.py/evaluation.py should call
# ============================================================================

ENGINE_LABELS = {
    "v18": "V18 Existing",
    "gemini-3.8-flash": "Gemini 3.8 Flash",
    "gemini-2.5-flash": "Gemini 2.5 Flash",
    "mistral-ocr-4-1": "Mistral OCR 4.1",
    "qwen2_vl": "Qwen2-VL-2B-Instruct",
}

ENGINES = tuple(ENGINE_LABELS)


def run(engine, document_path, progress_callback=None, reference_record=None):
    """SINGLE dispatch point -- exactly one branch executes per call, never a
    fan-out to multiple engines, never an automatic fallback between them
    (Qwen's OWN internal fallback to v18, run_qwen_vlm above, is the one
    documented exception -- task spec section 6 -- and stays entirely inside
    that single dispatch branch)."""
    if engine == "v18":
        result = run_v18(document_path, progress_callback=progress_callback, reference_record=reference_record)
    elif engine == "gemini-3.8-flash":
        result = run_gemini(document_path, model="gemini-3.8-flash", progress_callback=progress_callback)
    elif engine == "gemini-2.5-flash":
        result = run_gemini(document_path, model="gemini-2.5-flash", progress_callback=progress_callback)
    elif engine == "mistral-ocr-4-1":
        result = run_mistral(document_path, model="mistral-ocr-4-1", progress_callback=progress_callback)
    elif engine == "qwen2_vl":
        result = run_qwen_vlm(document_path, progress_callback=progress_callback, reference_record=reference_record)
    else:
        raise InvalidExtractor(engine)
    # V19 sec 5 -- metadata.version stamp, same for every engine (comparison
    # mode wants this consistently present, task spec section 11).
    result.setdefault("ocr_meta", {})["version"] = "v19"
    return result
