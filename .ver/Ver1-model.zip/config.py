"""
config.py
=========
V19 -- centralized app configuration. Currently only Gemini token pricing +
the USD/IDR conversion rate (task spec section 8: "pricing configuration
must be easy to update when Gemini pricing changes" -- NOT hardcoded
throughout the app). extractors.py reads these constants, never hardcodes a
number itself -- update the numbers here when Gemini's published pricing or
the exchange rate changes, nothing else needs to change.

NOTE: these are the two GEMINI_PRICING entries needed for the two model ids
currently in extractors.ENGINE_LABELS ("gemini-3.8-flash"/"gemini-2.5-flash").
Values below are best-effort at time of writing and NOT re-verified against
Gemini's live pricing page in this sandbox (no outbound network access here,
same limitation already documented in handover.md for the Gemini API calls
themselves) -- confirm against https://ai.google.dev/gemini-api/docs/pricing
before trusting cost figures in production.
"""

# USD per 1,000,000 tokens. "output_per_1m" covers BOTH candidate output
# tokens AND thinking tokens (task spec section 8's cost formula sums them
# before applying this rate).
GEMINI_PRICING = {
    "gemini-2.5-flash": {"input_per_1m": 0.30, "output_per_1m": 2.50},
    # "gemini-3.8-flash" is a forward-looking/placeholder model id in this
    # codebase (see extractors.ENGINE_LABELS) -- no published pricing exists
    # yet, so it falls through to GEMINI_DEFAULT_PRICING below until Google
    # publishes real numbers for it (update this dict then, don't guess).
}

GEMINI_DEFAULT_PRICING = {"input_per_1m": 0.30, "output_per_1m": 2.50}

USD_IDR_RATE = 16300.0
